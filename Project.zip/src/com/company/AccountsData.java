package com.company;

class AccountsData
{
    private String userArray[]     = {"meer",  "adil","bilal", "zeeshan"};
    private String passArray[]     = {"meer123", "ad268",  "bilo12",    "-456!"};
    private float balanceArray[]   = {1000.45f,      2500f,	45466.67f,	    67780};
    private String phoneArray[]    = {"0316-xxxxxxx","0311-xxxxxxx","0315-xxxxxxx","0333-xxxxxxx"};
    private String adressArray[]   = {"Street 1,House C-40,karachi Sindh","Street x,House C-xx,hyderabad Sindh","Street x,House C-xx,Sukkur Sindh","Street x,House C-xx,Sukkur Sindh"};
    private String emailArray[]    = {"khalilmir317@gmail.com","adil0000@gmail.com","bilalxxx@gmail.coom","uzairxxx@gmail.com"};

    public String[] getUserName()
    {
        return userArray;
    }

    public String[] getPassword()
    {
        return passArray;
    }

    public float[] getBalance()
    {
        return balanceArray;
    }

    public String[] getPhone()
    {
        return phoneArray;
    }

    public String[] getAdress()
    {
        return adressArray;
    }

    public String[] getEmail()
    {
        return emailArray;
    }


}



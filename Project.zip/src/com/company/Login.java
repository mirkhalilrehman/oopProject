package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



class Login extends AccountsData implements ActionListener
{

    int index = 0;
    ImageIcon image=new ImageIcon("atm.jfif");
    String userArr[] = getUserName();
    String passArr[] = getPassword();


    JFrame loginframe = new JFrame("Login to ATM");
    JButton login,cancel,bregister;
    JTextField userfield = new JTextField();
    JTextField passfield = new JTextField();
    JLabel loginlabel = new JLabel("Login");
    JPanel panel1= new JPanel();
    JPanel panel2 = new JPanel();
    JPanel panel3 = new JPanel();


    Login()
    {
        loginframe.setLayout(new BorderLayout());

        //Create Components
        login = new JButton("Login");
        cancel = new JButton("Cancel");
        bregister = new JButton("Register?");


        //Edit component
        userfield.setBackground(Color.white);
        userfield.setForeground(Color.black);
        userfield.setCaretColor(Color.black);
        userfield.setPreferredSize(new Dimension(170,30));
        userfield.setFont(new Font("SansSarif Italic", Font.PLAIN, 14));
        userfield.setText("Username");

        passfield.setBackground(Color.white);
        passfield.setForeground(Color.BLACK);
        passfield.setCaretColor(Color.BLACK);
        passfield.setPreferredSize(new Dimension(170,30));
        passfield.setFont(new Font("SansSarif Italic", Font.PLAIN, 14));
        passfield.setText("Password");


        loginlabel.setFont(new Font("Monospaced", Font.BOLD, 30));
        loginlabel.setForeground(Color.green);

        panel1.setLayout( new FlowLayout());
        panel1.setBackground(new Color(159,172,100));

        panel2.setLayout( new FlowLayout());
        panel2.setBackground(new Color(159,172,100));


        panel3.setLayout( new FlowLayout());
        panel3.setBackground(new Color(159,172,100));

        bregister.setForeground(Color.black);
        bregister.setFocusable(false);

        login.setForeground(Color.black);
        login.setFocusable(false);

        cancel.setForeground(Color.black);
        cancel.setFocusable(false);

        //Add Component
        panel1.add(loginlabel);
        panel2.add(userfield);
        panel2.add(passfield);
        panel2.add(login);
        panel2.add(cancel);
        panel3.add(bregister);
        loginframe.add(panel1, BorderLayout.NORTH);
        loginframe.add(panel2, BorderLayout.CENTER);
        loginframe.add(panel3, BorderLayout.SOUTH);

        //Action Listenera
        login.addActionListener(this);
        cancel.addActionListener(this);
        bregister.addActionListener(this);




        //Frame
        loginframe.getContentPane().setBackground(new Color(123,50,250));
        loginframe.setSize(600,500);
        loginframe.setResizable(true);
        loginframe.setVisible(true);
        loginframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginframe.setIconImage(image.getImage());

    }

    public void actionPerformed(ActionEvent e)
    {
        if(e.getSource()==bregister)
        {
            JOptionPane.showMessageDialog(null, "Problem occured ,visit your nearest branch of Bank", "Register", JOptionPane.ERROR_MESSAGE);

        }

        else if(e.getSource()==cancel)
        {
            loginframe.dispose();
        }

        else if(e.getSource()==login)
        {
            boolean match=false;
            String u_name = userfield.getText().toString();
            String u_pass = passfield.getText().toString();

            for(int i=0; i<userArr.length; i++)
            {
                if((u_name.equals(userArr[i]))&& (u_pass.equals(passArr[i])))
                {
                    match=true;
                    index=i;
                    break;
                }
            }

            if(match)
            {
                JOptionPane.showMessageDialog(null, "Login Succesfull", "Log in", JOptionPane.INFORMATION_MESSAGE);
                loginframe.dispose();
                ATM atm = new ATM(index);
            }
            else
                JOptionPane.showMessageDialog(null, "Wrong User and Password", "Login", JOptionPane.ERROR_MESSAGE);
        }
    }
}

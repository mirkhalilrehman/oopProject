package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class ATM extends AccountsData implements ActionListener
{

    int index = 0;
    String userArr[] = getUserName();
    String passArr[] = getPassword();
    float balanceArr[] = getBalance();
    String phoneArr[] = getPhone();
    String adressArr[] = getAdress();
    String emailArr[] = getEmail();

    ImageIcon image=new ImageIcon("atm.jfif");
    JFrame ATMframe = new JFrame("Online ATM");
    JButton bdeposite,bwithdraw,bcheckbalance,bexit,baccinfo,bother;

    JTextField inputfield = new JTextField();

    JLabel atmlabel = new JLabel("ATM");

    JLabel namelabel = new JLabel("Name:\t");
    JLabel nameoutput = new JLabel(userArr[index]);
    JLabel balancelabel = new JLabel("Balance:\t");
    JLabel balanceoutput = new JLabel("$0.0");
    JLabel displaymsg = new JLabel("Enter Amount");
    JPanel panel= new JPanel();
    JPanel panel2= new JPanel();

    ATM(int i)
    {
        index = i;
        String bal = "$"+Float.toString(balanceArr[index]);
        nameoutput.setText(userArr[index]);
        balanceoutput.setText(bal);

        ATMframe.setLayout(new BorderLayout());
        ATMframe.setBackground(new Color(0,114,160));

        panel.setLayout(new FlowLayout());
        panel.setBackground(new Color(159,172,100));

        panel2.setLayout(new FlowLayout());
        panel2.setBackground(new Color(159,172,100));

        displaymsg.setFont(new Font("Georgia", Font.PLAIN, 14));
        displaymsg.setForeground(Color.white);
        namelabel.setFont(new Font("Georgia", Font.PLAIN, 14));
        namelabel.setForeground(Color.white);
        nameoutput.setFont(new Font("SansSarif Italic", Font.ITALIC, 17));
        nameoutput.setForeground(Color.white);
        balancelabel.setFont(new Font("Georgia", Font.PLAIN, 14));
        balancelabel.setForeground(Color.white);
        balanceoutput.setFont(new Font("SansSarif Italic", Font.ITALIC, 17));
        balanceoutput.setForeground(Color.white);

        inputfield.setBackground(Color.black);
        inputfield.setForeground(Color.white);
        inputfield.setCaretColor(Color.white);
        inputfield.setPreferredSize(new Dimension(170,20));
        inputfield.setFont(new Font("SansSarif Italic", Font.PLAIN, 14));
        inputfield.setText("");

        bwithdraw = new JButton("Withdraw");
        bdeposite = new JButton("Deposite");
        bcheckbalance = new JButton("View Balance");
        baccinfo = new JButton("Account Info");
        bexit =new JButton("Logout");
        bother = new JButton("Other");

        //Turn off focus while clicking on buttons
        bwithdraw.setFocusable(false);
        bdeposite.setFocusable(false);
        bcheckbalance.setFocusable(false);
        baccinfo.setFocusable(false);
        bexit.setFocusable(false);
        bother.setFocusable(false);

        panel.add(displaymsg);
        panel.add(inputfield);
        panel.add(bwithdraw);
        panel.add(bdeposite);
        panel.add(baccinfo);
        panel.add(bexit);

        panel2.add(namelabel);
        panel2.add(nameoutput);
        panel2.add(balancelabel);
        panel2.add(balanceoutput);
        ATMframe.add(panel, BorderLayout.CENTER);
        ATMframe.add(panel2, BorderLayout.WEST);


        //Action listener
        bwithdraw.addActionListener(this);
        bdeposite.addActionListener(this);
        baccinfo.addActionListener(this);
        bexit.addActionListener(this);


        ATMframe.setSize(600,400);
        ATMframe.setResizable(false);
        ATMframe.setVisible(true);
        ATMframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ATMframe.setIconImage(image.getImage());
    }

    public void actionPerformed(ActionEvent e)
    {
        String temp="";
        int amount=0;

        if(e.getSource()==bwithdraw)
        {

            if(inputfield.getText().equals(""))
            {
                JOptionPane.showMessageDialog(null, "Enter amount please", "Input", JOptionPane.INFORMATION_MESSAGE);
            }

            else
            {
                temp=inputfield.getText();
                amount=Integer.parseInt(temp);

                if(amount>balanceArr[index])
                {
                    JOptionPane.showMessageDialog(null, "Amount not available ", "Input", JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    balanceArr[index]-=amount;
                    JOptionPane.showMessageDialog(null, "Withdraw successful", "", JOptionPane.INFORMATION_MESSAGE);
                    String balance = "$"+Float.toString(balanceArr[index]);
                    balanceoutput.setText(balance);
                }
            }
        }

        else if(e.getSource()==bdeposite)
        {

            if(inputfield.getText().equals(""))
            {
                JOptionPane.showMessageDialog(null, "Enter amount please", "Input", JOptionPane.INFORMATION_MESSAGE);
            }

            else
            {
                temp=inputfield.getText();
                amount=Integer.parseInt(temp);

                if(amount<=0)
                {
                    JOptionPane.showMessageDialog(null, "Amount can't be negative", "Input", JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    balanceArr[index]+=amount;
                    JOptionPane.showMessageDialog(null, "Deposit successful", "", JOptionPane.INFORMATION_MESSAGE);
                    String balance = "$"+Float.toString(balanceArr[index]);
                    balanceoutput.setText(balance);
                }
            }
        }

        else if(e.getSource()==baccinfo)
        {
            JOptionPane.showMessageDialog(null, getAccountInfo() , "Account Information", JOptionPane.INFORMATION_MESSAGE);
        }

        else if(e.getSource()==bexit)
        {
            new Login();
            ATMframe.dispose();
        }
    }

    String getAccountInfo()
    {
        String s = "Username: "+userArr[index]+"\nPassword: "+passArr[index]+"\nContact: "+phoneArr[index]+"\nEmail: "+emailArr[index]+"\nBalance: "+balanceArr[index]+"\nAdress: "+adressArr[index] ;
        return s;
    }
}
